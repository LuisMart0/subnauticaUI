package com.example.subnauticaui.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight

@Composable
fun PantallaConfiguracion(
    onNavigateBack: () -> Unit,
    onNavigateToAbout: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PDA_Fondo)
            .padding(24.dp),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "> AJUSTES DE SISTEMAS",
                color = SubnauticaVerde,
                fontSize = 18.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Secciones de información de la PDA
            Text(
                text = "Volumen del PDA: 75%",
                color = SubnauticaAzul,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Brillo de pantalla: 90%",
                color = Color.White,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Idioma: ESPAÑOL",
                color = Color.White,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace
            )

            Spacer(modifier = Modifier.weight(1f)) // flex

            // Cont para botones
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Button(onClick = onNavigateToAbout) {
                    Text(text = "Información del Sistema")
                }
                Spacer(modifier = Modifier.height(8.dp))
                Button(onClick = onNavigateBack) {
                    Text(text = "Volver al Menú Principal")
                }
            }
        }
    }
}

@Composable
fun PantallaAcercaDe() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PDA_Fondo)
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            // Título de la pantalla
            Text(
                text = "> ACERCA DEL DISPOSITIVO",
                color = SubnauticaAzul,
                fontSize = 18.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Información con estilo de PDA
            Text(
                text = "> Versión del Sistema Operativo: B-2022-SP1",
                color = SubnauticaVerde,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "> Número de Serie del PDA: 8295-D-203-A",
                color = Color.White,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "> Advertencia: Se detectan fallas de integridad en la memoria. Se recomienda un formateo del sistema.",
                color = SubnauticaAmarillo,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}