package com.example.subnauticaui.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight

// Colores de la interfaz
val PDA_Fondo = Color(0xFF1E3A4B)
val SubnauticaAzul = Color(0xFF00BFFF)
val SubnauticaVerde = Color(0xFF32CD32)
val SubnauticaAmarillo = Color(0xFFFFFF00)

// funcion de nav
@Composable
fun PantallaSubnautica(onNavigateToSettings: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PDA_Fondo)
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            // Stats del personaje
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Barra de SALUD
                Column {
                    Text(
                        text = "SALUD",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .width(100.dp)
                            .height(8.dp)
                            .background(SubnauticaVerde)
                    )
                }
                // Barra de OXÍGENO
                Column {
                    Text(
                        text = "OXIGENO",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .width(100.dp)
                            .height(8.dp)
                            .background(SubnauticaAzul)
                    )
                }
            }
            Spacer(modifier = Modifier.height(40.dp))
            // Contenedor principal de la PDA
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(350.dp)
                    .background(Color.White.copy(alpha = 0.1f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "> INICIANDO PDA...",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "> REPORTE DE SISTEMAS:",
                        color = SubnauticaAzul,
                        fontSize = 14.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Profundidad: 150m\nTemperatura: 12°C\nBioma: Arrecife de coral",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(
                        text = "> ¡Advertencia! Se ha detectado una nueva forma de vida",
                        color = SubnauticaAmarillo,
                        fontSize = 14.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
            Button(onClick = onNavigateToSettings) {
                Text(text = "Ir a Configuración")
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PrevisualizacionSubnautica() {
    PantallaSubnautica(onNavigateToSettings = {})
}