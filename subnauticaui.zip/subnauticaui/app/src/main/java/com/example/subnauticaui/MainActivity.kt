package com.example.subnauticaui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.subnauticaui.ui.theme.PantallaSubnautica
import com.example.subnauticaui.ui.theme.PantallaConfiguracion
import com.example.subnauticaui.ui.theme.PantallaAcercaDe
import com.example.subnauticaui.ui.theme.SubnauticauiTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SubnauticauiTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    NavHost(navController = navController, startDestination = "main_screen") {
                        composable("main_screen") {
                            PantallaSubnautica(
                                onNavigateToSettings = {
                                    navController.navigate("configuracion_screen")
                                }
                            )
                        }
                        composable("configuracion_screen") {
                            PantallaConfiguracion(
                                onNavigateBack = {
                                    navController.popBackStack()
                                },
                                onNavigateToAbout = {
                                    navController.navigate("acerca_de_screen")
                                }
                            )
                        }
                        composable("acerca_de_screen") {
                            PantallaAcercaDe()
                        }
                    }
                }
            }
        }
    }
}